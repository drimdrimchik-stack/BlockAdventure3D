using UnityEngine;

public static class BlockId
{
    public const byte Air = 0, Grass = 1, Dirt = 2, Stone = 3, Sand = 4, Wood = 5,
        Leaves = 6, Water = 7, Snow = 8, Planks = 9, Cobble = 10, Bedrock = 11;
    public const int Count = 12;
}

public static class Blocks
{
    static readonly Color32[] top = new Color32[BlockId.Count];
    static readonly Color32[] side = new Color32[BlockId.Count];
    static readonly Color32[] bottom = new Color32[BlockId.Count];
    // seconds to break; -1 = unbreakable
    static readonly float[] hardness = { 0f, 0.6f, 0.5f, 1.5f, 0.5f, 1.0f, 0.2f, 0f, 0.3f, 0.8f, 1.6f, -1f };

    static void Set(byte id, Color32 t, Color32 s, Color32 b) { top[id] = t; side[id] = s; bottom[id] = b; }
    static void Set(byte id, Color32 c) { Set(id, c, c, c); }
    static Color32 C(int r, int g, int b, int a = 255) { return new Color32((byte)r, (byte)g, (byte)b, (byte)a); }

    static Blocks()
    {
        Set(BlockId.Grass, C(95, 159, 53), C(112, 118, 56), C(121, 85, 58));
        Set(BlockId.Dirt, C(121, 85, 58));
        Set(BlockId.Stone, C(125, 125, 128));
        Set(BlockId.Sand, C(219, 207, 142));
        Set(BlockId.Wood, C(150, 120, 70), C(102, 81, 51), C(150, 120, 70));
        Set(BlockId.Leaves, C(52, 122, 43));
        Set(BlockId.Water, C(50, 100, 200, 150));
        Set(BlockId.Snow, C(240, 245, 250), C(226, 232, 238), C(121, 85, 58));
        Set(BlockId.Planks, C(176, 141, 87));
        Set(BlockId.Cobble, C(105, 105, 108));
        Set(BlockId.Bedrock, C(40, 40, 40));
    }

    // face: 0=+X 1=-X 2=+Y(top) 3=-Y(bottom) 4=+Z 5=-Z
    public static Color32 FaceColor(byte b, int face)
    {
        if (face == 2) return top[b];
        if (face == 3) return bottom[b];
        return side[b];
    }
    public static float Hardness(byte b) { return hardness[b]; }
    public static bool Targetable(byte b) { return b != BlockId.Air && b != BlockId.Water; }
}
