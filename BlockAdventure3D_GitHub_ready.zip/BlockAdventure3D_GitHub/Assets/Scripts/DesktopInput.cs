using UnityEngine;

[DefaultExecutionOrder(-100)]
public class DesktopInput : MonoBehaviour
{
    bool locked, ignoreUntilRelease;
    const float MouseSens = 2.2f;

    void Update()
    {
        if (Application.isMobilePlatform) return;
        InputState.BeginFrame();

        if (Input.GetKeyDown(KeyCode.F) && PerformanceManager.I != null) PerformanceManager.I.CycleTarget();
        if (Input.GetKeyDown(KeyCode.F11)) Screen.fullScreen = !Screen.fullScreen;
        if (Input.GetKeyDown(KeyCode.Escape)) SetLock(false);

        if (!locked)
        {
            if (Input.GetMouseButtonDown(0)) { SetLock(true); ignoreUntilRelease = true; }
            return;
        }

        InputState.Move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        InputState.Look = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * MouseSens * InputState.LookSens;
        InputState.Jump = Input.GetKey(KeyCode.Space);
        InputState.Sprint = Input.GetKey(KeyCode.LeftShift);
        if (!Input.GetMouseButton(0)) ignoreUntilRelease = false;
        InputState.BreakHeld = Input.GetMouseButton(0) && !ignoreUntilRelease;
        InputState.PlacePressed = Input.GetMouseButtonDown(1);

        float s = Input.mouseScrollDelta.y;
        if (s > 0) InputState.SelectOffset(-1);
        else if (s < 0) InputState.SelectOffset(1);
        for (int i = 0; i < 9; i++)
            if (Input.GetKeyDown(KeyCode.Alpha1 + i)) InputState.Selected = i;
    }

    void SetLock(bool v)
    {
        locked = v;
        Cursor.lockState = v ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !v;
    }
}
