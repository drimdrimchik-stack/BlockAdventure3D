using UnityEngine;

public class WorldGenerator
{
    public const int Sea = 20;
    public readonly int seed;

    public WorldGenerator(int seed) { this.seed = seed; }

    public int Height(int wx, int wz)
    {
        float c = NoiseUtil.Fbm2(wx * 0.008f, wz * 0.008f, seed, 4);
        float h = 22f + (c - 0.5f) * 70f;
        float m = Mathf.Max(0f, NoiseUtil.Fbm2(wx * 0.004f + 500f, wz * 0.004f + 500f, seed + 1, 3) - 0.5f) * 2.2f;
        h += m * 70f;
        return Mathf.Clamp(Mathf.RoundToInt(h), 3, Chunk.H - 8);
    }

    // Вызывается из фонового потока
    public void Generate(int cx, int cz, byte[] d)
    {
        System.Array.Clear(d, 0, d.Length);
        int[] heights = new int[Chunk.W * Chunk.W];

        for (int x = 0; x < Chunk.W; x++)
        for (int z = 0; z < Chunk.W; z++)
        {
            int wx = cx * Chunk.W + x, wz = cz * Chunk.W + z;
            int h = Height(wx, wz);
            heights[x | (z << 4)] = h;
            byte surf = h <= Sea + 1 ? BlockId.Sand : h >= 46 ? BlockId.Snow : h >= 38 ? BlockId.Stone : BlockId.Grass;
            byte under = surf == BlockId.Grass ? BlockId.Dirt : (surf == BlockId.Sand ? BlockId.Sand : BlockId.Stone);

            for (int y = 0; y <= h; y++)
            {
                byte b;
                if (y == 0) b = BlockId.Bedrock;
                else if (y == h) b = surf;
                else if (y >= h - 3) b = under;
                else b = BlockId.Stone;
                if (y > 3 && y < h - 2 && NoiseUtil.Value3(wx * 0.07f, y * 0.1f, wz * 0.07f, seed + 99) > 0.74f)
                    b = BlockId.Air;
                d[Chunk.Idx(x, y, z)] = b;
            }
            for (int y = h + 1; y <= Sea; y++) d[Chunk.Idx(x, y, z)] = BlockId.Water;
        }

        // Деревья (только внутри чанка, чтобы не лезть в соседние)
        for (int x = 2; x <= 13; x++)
        for (int z = 2; z <= 13; z++)
        {
            int h = heights[x | (z << 4)];
            if (h <= Sea + 1 || d[Chunk.Idx(x, h, z)] != BlockId.Grass) continue;
            int wx = cx * Chunk.W + x, wz = cz * Chunk.W + z;
            if (NoiseUtil.Hash(wx, 7, wz, seed) >= 0.015f) continue;
            int th = 4 + (int)(NoiseUtil.Hash(wx, 8, wz, seed) * 2.99f);
            for (int dy = 1; dy <= th; dy++) d[Chunk.Idx(x, h + dy, z)] = BlockId.Wood;
            for (int dy = th - 2; dy <= th + 1; dy++)
            {
                int r = dy >= th ? 1 : 2;
                for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                {
                    if (r == 2 && Mathf.Abs(dx) == 2 && Mathf.Abs(dz) == 2) continue;
                    int i = Chunk.Idx(x + dx, h + dy, z + dz);
                    if (d[i] == BlockId.Air) d[i] = BlockId.Leaves;
                }
            }
        }
    }
}
