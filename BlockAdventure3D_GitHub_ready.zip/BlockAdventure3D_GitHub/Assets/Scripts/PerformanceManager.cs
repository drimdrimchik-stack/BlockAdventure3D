using UnityEngine;

// Лимит FPS (30/45/60) и автоподстройка дальности прорисовки
public class PerformanceManager : MonoBehaviour
{
    public static PerformanceManager I;
    public float Fps { get; private set; }
    public int TargetFps = 60;

    int frames, minR = 3, maxR;
    float acc, sinceChange = 10f;

    void Awake()
    {
        I = this;
        QualitySettings.vSyncCount = 0;
        TargetFps = PlayerPrefs.GetInt("ba_fps", 60);
        Application.targetFrameRate = TargetFps;
        maxR = Application.isMobilePlatform ? 8 : 14;
    }

    public void CycleTarget()
    {
        TargetFps = TargetFps == 30 ? 45 : (TargetFps == 45 ? 60 : 30);
        PlayerPrefs.SetInt("ba_fps", TargetFps);
        Application.targetFrameRate = TargetFps;
    }

    void Update()
    {
        float dt = Time.unscaledDeltaTime;
        frames++; acc += dt; sinceChange += dt;
        if (acc >= 1f)
        {
            Fps = frames / acc;
            frames = 0; acc = 0f;
            Adapt();
        }
    }

    void Adapt()
    {
        var cm = ChunkManager.I;
        if (cm == null || cm.fastLoad) return;
        if (Fps < TargetFps * 0.88f && cm.renderDistance > minR)
        {
            cm.renderDistance--; sinceChange = 0f; cm.ApplyViewDistance();
        }
        else if (Fps >= TargetFps * 0.97f && sinceChange > 10f && cm.renderDistance < maxR)
        {
            cm.renderDistance++; sinceChange = 0f; cm.ApplyViewDistance();
        }
    }
}
