using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// Система чанков: асинхронная генерация, пул объектов, выгрузка дальних чанков
public class ChunkManager : MonoBehaviour
{
    public static ChunkManager I;
    public static readonly Color32 SkyColor = new Color32(135, 190, 235, 255);

    public int renderDistance = 6;
    public bool fastLoad = true;

    WorldGenerator gen;
    Transform player;
    Camera cam;
    Material solidMat, waterMat;

    readonly Dictionary<Vector2Int, Chunk> chunks = new Dictionary<Vector2Int, Chunk>();
    readonly Dictionary<Vector2Int, byte[]> savedData = new Dictionary<Vector2Int, byte[]>();
    readonly Stack<ChunkView> viewPool = new Stack<ChunkView>();
    readonly Stack<byte[]> arrayPool = new Stack<byte[]>();
    readonly List<Vector2Int> offsets = new List<Vector2Int>();
    readonly List<Vector2Int> removeList = new List<Vector2Int>();
    readonly Chunk[] nb = new Chunk[4];

    int running;
    const int MaxParallel = 3;
    Vector2Int lastPc = new Vector2Int(int.MinValue, 0);
    float scanTimer;

    public WorldGenerator Gen { get { return gen; } }

    public void Init(WorldGenerator g, Transform p, Material solid, Material water, Camera c)
    {
        I = this;
        gen = g; player = p; solidMat = solid; waterMat = water; cam = c;
        renderDistance = Application.isMobilePlatform ? 5 : 8;
        const int maxR = 18;
        for (int x = -maxR; x <= maxR; x++)
            for (int z = -maxR; z <= maxR; z++)
                if (x * x + z * z <= maxR * maxR) offsets.Add(new Vector2Int(x, z));
        offsets.Sort((a, b) => a.sqrMagnitude.CompareTo(b.sqrMagnitude));
        ApplyViewDistance();
    }

    public void ApplyViewDistance()
    {
        float end = renderDistance * Chunk.W * 0.92f;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = SkyColor;
        RenderSettings.fogStartDistance = end * 0.45f;
        RenderSettings.fogEndDistance = end;
        if (cam != null) cam.farClipPlane = renderDistance * Chunk.W + 40f;
    }

    void Update()
    {
        if (player == null) return;
        Vector3 p = player.position;
        var pc = new Vector2Int(Mathf.FloorToInt(p.x / Chunk.W), Mathf.FloorToInt(p.z / Chunk.W));
        scanTimer -= Time.deltaTime;
        if (scanTimer <= 0f || pc != lastPc)
        {
            scanTimer = 0.15f;
            lastPc = pc;
            Scan(pc);
        }
        MeshPass(pc);
    }

    void Scan(Vector2Int pc)
    {
        int genR = renderDistance + 1;
        int g2 = genR * genR;
        for (int i = 0; i < offsets.Count; i++)
        {
            var off = offsets[i];
            if (off.sqrMagnitude > g2) break;
            var key = pc + off;
            if (!chunks.ContainsKey(key))
            {
                if (!StartChunk(key)) break;
            }
        }

        int u2 = (renderDistance + 2) * (renderDistance + 2);
        removeList.Clear();
        foreach (var kv in chunks)
            if ((kv.Key - pc).sqrMagnitude > u2 && kv.Value.hasData) removeList.Add(kv.Key);
        for (int i = 0; i < removeList.Count; i++) Unload(removeList[i]);
    }

    bool StartChunk(Vector2Int key)
    {
        byte[] sd;
        if (savedData.TryGetValue(key, out sd))
        {
            chunks[key] = new Chunk { pos = key, data = sd, hasData = true, modified = true };
            savedData.Remove(key);
            return true;
        }
        if (running >= MaxParallel) return false;
        byte[] arr = arrayPool.Count > 0 ? arrayPool.Pop() : new byte[Chunk.W * Chunk.W * Chunk.H];
        var c = new Chunk { pos = key, data = arr };
        chunks[key] = c;
        Interlocked.Increment(ref running);
        int cx = key.x, cz = key.y;
        var g = gen;
        Task.Run(() =>
        {
            try { g.Generate(cx, cz, arr); }
            catch (System.Exception e) { Debug.LogException(e); }
            c.hasData = true;
            Interlocked.Decrement(ref running);
        });
        return true;
    }

    void Unload(Vector2Int key)
    {
        var c = chunks[key];
        if (c.view != null) { ReleaseView(c.view); c.view = null; }
        if (c.modified) savedData[key] = c.data; else arrayPool.Push(c.data);
        chunks.Remove(key);
    }

    bool NeighborsReady(Vector2Int k)
    {
        return Ready(k + Vector2Int.right) && Ready(k + Vector2Int.left) &&
               Ready(k + Vector2Int.up) && Ready(k + Vector2Int.down);
    }
    bool Ready(Vector2Int k) { Chunk c; return chunks.TryGetValue(k, out c) && c.hasData; }
    Chunk GetChunk(Vector2Int k) { Chunk c; chunks.TryGetValue(k, out c); return c; }

    void MeshPass(Vector2Int pc)
    {
        int maxMesh = fastLoad ? 6 : (Application.isMobilePlatform ? 1 : 2);
        int built = 0;
        int r2 = renderDistance * renderDistance;
        for (int i = 0; i < offsets.Count; i++)
        {
            var off = offsets[i];
            if (off.sqrMagnitude > r2) break;
            var key = pc + off;
            Chunk c;
            if (!chunks.TryGetValue(key, out c) || !c.hasData || !c.dirty) continue;
            if (!NeighborsReady(key)) continue;
            BuildChunk(c);
            if (++built >= maxMesh) break;
        }

        // Коллайдеры только рядом с игроком (экономим CPU)
        int cols = 0;
        for (int i = 0; i < offsets.Count; i++)
        {
            var off = offsets[i];
            if (off.sqrMagnitude > 9) break;
            Chunk c;
            if (!chunks.TryGetValue(pc + off, out c) || c.view == null || c.view.colliderAssigned) continue;
            AssignCollider(c.view);
            if (++cols >= 3) break;
        }
    }

    void AssignCollider(ChunkView v)
    {
        v.col.sharedMesh = null;
        if (v.solid.vertexCount > 0) v.col.sharedMesh = v.solid;
        v.colliderAssigned = true;
    }

    void BuildChunk(Chunk c)
    {
        if (c.view == null) c.view = GetView(c.pos);
        nb[0] = GetChunk(c.pos + Vector2Int.right);
        nb[1] = GetChunk(c.pos + Vector2Int.left);
        nb[2] = GetChunk(c.pos + Vector2Int.up);
        nb[3] = GetChunk(c.pos + Vector2Int.down);
        Mesher.Build(c, nb, c.view.solid, c.view.water);
        c.dirty = false;
        if (c.view.colliderAssigned) AssignCollider(c.view);
    }

    ChunkView GetView(Vector2Int pos)
    {
        ChunkView v = viewPool.Count > 0 ? viewPool.Pop() : NewView();
        v.go.transform.position = new Vector3(pos.x * Chunk.W, 0, pos.y * Chunk.W);
        v.go.SetActive(true);
        v.colliderAssigned = false;
        return v;
    }

    ChunkView NewView()
    {
        var v = new ChunkView();
        v.go = new GameObject("Chunk");
        v.go.transform.SetParent(transform);
        var mf = v.go.AddComponent<MeshFilter>();
        var mr = v.go.AddComponent<MeshRenderer>();
        mr.sharedMaterial = solidMat;
        mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        mr.receiveShadows = false;
        v.col = v.go.AddComponent<MeshCollider>();
        v.solid = new Mesh { name = "ChunkSolid" };
        mf.sharedMesh = v.solid;

        var wgo = new GameObject("Water");
        wgo.transform.SetParent(v.go.transform, false);
        var wmf = wgo.AddComponent<MeshFilter>();
        var wmr = wgo.AddComponent<MeshRenderer>();
        wmr.sharedMaterial = waterMat;
        wmr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        wmr.receiveShadows = false;
        v.water = new Mesh { name = "ChunkWater" };
        wmf.sharedMesh = v.water;
        return v;
    }

    void ReleaseView(ChunkView v)
    {
        v.solid.Clear(); v.water.Clear();
        v.col.sharedMesh = null;
        v.colliderAssigned = false;
        v.go.SetActive(false);
        viewPool.Push(v);
    }

    // ---------- доступ к блокам ----------
    public byte GetBlock(int wx, int wy, int wz)
    {
        if (wy < 0) return BlockId.Bedrock;
        if (wy >= Chunk.H) return BlockId.Air;
        Chunk c;
        if (!chunks.TryGetValue(new Vector2Int(wx >> 4, wz >> 4), out c) || !c.hasData) return BlockId.Air;
        return c.data[Chunk.Idx(wx & 15, wy, wz & 15)];
    }

    public void SetBlock(int wx, int wy, int wz, byte b)
    {
        if (wy < 0 || wy >= Chunk.H) return;
        Chunk c;
        if (!chunks.TryGetValue(new Vector2Int(wx >> 4, wz >> 4), out c) || !c.hasData) return;
        int lx = wx & 15, lz = wz & 15;
        c.data[Chunk.Idx(lx, wy, lz)] = b;
        c.modified = true;
        Rebuild(c);
        if (lx == 0) Rebuild(GetChunk(c.pos + Vector2Int.left));
        if (lx == 15) Rebuild(GetChunk(c.pos + Vector2Int.right));
        if (lz == 0) Rebuild(GetChunk(c.pos + Vector2Int.down));
        if (lz == 15) Rebuild(GetChunk(c.pos + Vector2Int.up));
    }

    void Rebuild(Chunk c)
    {
        if (c == null || !c.hasData) return;
        if (c.view == null) { c.dirty = true; return; }
        BuildChunk(c);
    }

    public bool IsReadyAround(Vector3 p)
    {
        var pc = new Vector2Int(Mathf.FloorToInt(p.x / Chunk.W), Mathf.FloorToInt(p.z / Chunk.W));
        for (int x = -1; x <= 1; x++)
            for (int z = -1; z <= 1; z++)
            {
                Chunk c;
                if (!chunks.TryGetValue(pc + new Vector2Int(x, z), out c) || c.view == null || !c.view.colliderAssigned)
                    return false;
            }
        return true;
    }
}
