using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public bool Ready { get; private set; }

    CharacterController cc;
    CameraController camCtl;
    Vector3 vel, spawn;

    const float Gravity = 28f, JumpV = 8.5f, Walk = 4.6f, Run = 6.2f, Swim = 2.6f;

    public void Init(CameraController cam, Vector3 spawnPos)
    {
        cc = GetComponent<CharacterController>();
        camCtl = cam;
        spawn = spawnPos;
        Teleport(spawnPos);
    }

    void Teleport(Vector3 p)
    {
        cc.enabled = false;
        transform.position = p;
        cc.enabled = true;
        vel = Vector3.zero;
    }

    void Update()
    {
        var cm = ChunkManager.I;
        if (cm == null) return;

        if (!Ready)
        {
            if (!cm.IsReadyAround(transform.position)) return;
            Ready = true;
            cm.fastLoad = false;
        }

        float dt = Time.deltaTime;
        Vector2 look = InputState.Look;
        transform.Rotate(0f, look.x, 0f);
        camCtl.AddPitch(-look.y);

        Vector3 p = transform.position;
        bool inWater = cm.GetBlock(Mathf.FloorToInt(p.x), Mathf.FloorToInt(p.y + 0.4f), Mathf.FloorToInt(p.z)) == BlockId.Water;

        Vector2 m = InputState.Move;
        Vector3 wish = transform.right * m.x + transform.forward * m.y;
        if (wish.sqrMagnitude > 1f) wish.Normalize();
        float spd = inWater ? Swim : (InputState.Sprint ? Run : Walk);

        if (inWater)
        {
            vel.y = Mathf.Max(vel.y - 8f * dt, -3f);
            if (InputState.Jump) vel.y = 3.5f;
        }
        else
        {
            bool grounded = cc.isGrounded;
            if (grounded && vel.y < 0f) vel.y = -2f;
            if (grounded && InputState.Jump) vel.y = JumpV;
            vel.y = Mathf.Max(vel.y - Gravity * dt, -50f);
        }

        cc.Move((wish * spd + Vector3.up * vel.y) * dt);

        if (transform.position.y < -30f) Teleport(spawn);
    }
}
