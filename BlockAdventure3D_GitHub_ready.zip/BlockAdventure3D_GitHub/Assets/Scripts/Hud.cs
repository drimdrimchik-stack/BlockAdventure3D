using UnityEngine;

public static class UIScale
{
    public const float H = 600f;
    public static float S { get { return Screen.height / H; } }
    public static float W { get { return Screen.width / S; } }
}

// Хотбар, прицел, FPS, экран загрузки
public class Hud : MonoBehaviour
{
    public PlayerController player;
    GUIStyle lbl, center;

    public static Rect Slot(int i)
    {
        float w = 44f, g = 4f, total = 9 * w + 8 * g;
        return new Rect((UIScale.W - total) / 2f + i * (w + g), 8f, w, w);
    }

    public static void Box(Rect r, Color c)
    {
        GUI.color = c;
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = Color.white;
    }

    void OnGUI()
    {
        if (Event.current.type != EventType.Repaint) return;
        var old = GUI.matrix;
        GUI.matrix = Matrix4x4.Scale(new Vector3(UIScale.S, UIScale.S, 1f));
        if (lbl == null)
        {
            lbl = new GUIStyle(GUI.skin.label) { fontSize = 16 };
            lbl.normal.textColor = Color.white;
            center = new GUIStyle(lbl) { alignment = TextAnchor.MiddleCenter, fontSize = 26 };
        }

        for (int i = 0; i < 9; i++)
        {
            Rect r = Slot(i);
            if (i == InputState.Selected)
                Box(new Rect(r.x - 3, r.y - 3, r.width + 6, r.height + 6), Color.white);
            Box(r, new Color(0f, 0f, 0f, 0.6f));
            Box(new Rect(r.x + 6, r.y + 6, r.width - 12, r.height - 12), Blocks.FaceColor(BlockSystem.Hotbar[i], 2));
        }

        float cx = UIScale.W / 2f, cy = UIScale.H / 2f;
        Box(new Rect(cx - 8, cy - 1, 16, 2), new Color(1, 1, 1, 0.8f));
        Box(new Rect(cx - 1, cy - 8, 2, 16), new Color(1, 1, 1, 0.8f));

        var pm = PerformanceManager.I; var cm = ChunkManager.I;
        if (pm != null && cm != null)
            GUI.Label(new Rect(8, 8, 300, 24), "FPS " + Mathf.RoundToInt(pm.Fps) + " / " + pm.TargetFps + "   view " + cm.renderDistance, lbl);

        if (player != null && !player.Ready)
        {
            Box(new Rect(0, 0, UIScale.W, UIScale.H), new Color(0.1f, 0.15f, 0.2f, 1f));
            GUI.Label(new Rect(0, 0, UIScale.W, UIScale.H), "Loading world...", center);
        }
        GUI.matrix = old;
    }
}
