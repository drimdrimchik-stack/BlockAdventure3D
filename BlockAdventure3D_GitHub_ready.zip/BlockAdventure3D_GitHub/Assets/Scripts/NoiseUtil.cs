using UnityEngine;

// Потокобезопасный шум (Mathf.PerlinNoise нельзя звать из фоновых потоков)
public static class NoiseUtil
{
    public static float Hash(int x, int y, int z, int seed)
    {
        unchecked
        {
            int h = x * 374761393 ^ y * 668265263 ^ z * 1274126177 ^ seed * 362437;
            h = (h ^ (h >> 13)) * 1274126177;
            h ^= h >> 16;
            return (h & 0x7fffffff) / 2147483647f;
        }
    }

    static float S(float t) { return t * t * (3f - 2f * t); }

    public static float Value2(float x, float z, int seed)
    {
        int xi = Mathf.FloorToInt(x), zi = Mathf.FloorToInt(z);
        float fx = S(x - xi), fz = S(z - zi);
        float a = Hash(xi, 0, zi, seed), b = Hash(xi + 1, 0, zi, seed);
        float c = Hash(xi, 0, zi + 1, seed), d = Hash(xi + 1, 0, zi + 1, seed);
        return Mathf.Lerp(Mathf.Lerp(a, b, fx), Mathf.Lerp(c, d, fx), fz);
    }

    public static float Value3(float x, float y, float z, int seed)
    {
        int xi = Mathf.FloorToInt(x), yi = Mathf.FloorToInt(y), zi = Mathf.FloorToInt(z);
        float fx = S(x - xi), fy = S(y - yi), fz = S(z - zi);
        float a = Mathf.Lerp(Hash(xi, yi, zi, seed), Hash(xi + 1, yi, zi, seed), fx);
        float b = Mathf.Lerp(Hash(xi, yi, zi + 1, seed), Hash(xi + 1, yi, zi + 1, seed), fx);
        float c = Mathf.Lerp(Hash(xi, yi + 1, zi, seed), Hash(xi + 1, yi + 1, zi, seed), fx);
        float d = Mathf.Lerp(Hash(xi, yi + 1, zi + 1, seed), Hash(xi + 1, yi + 1, zi + 1, seed), fx);
        return Mathf.Lerp(Mathf.Lerp(a, b, fz), Mathf.Lerp(c, d, fz), fy);
    }

    public static float Fbm2(float x, float z, int seed, int octaves)
    {
        float sum = 0f, amp = 1f, norm = 0f, f = 1f;
        for (int i = 0; i < octaves; i++)
        {
            sum += Value2(x * f, z * f, seed + i * 31) * amp;
            norm += amp; amp *= 0.5f; f *= 2f;
        }
        return sum / norm;
    }
}
