using UnityEngine;

// Сенсорное управление: плавающий джойстик слева, свайп-камера справа, кнопки
[DefaultExecutionOrder(-100)]
public class MobileUI : MonoBehaviour
{
    Texture2D circle;
    GUIStyle btn;
    int joyId = -1, lookId = -1, jumpId = -1, breakId = -1;
    Vector2 joyOrigin, joyPos, lookAcc;
    const float JoyR = 70f;
    float buttonAlpha = 0.45f;

    static Rect Circ(Vector2 c, float r) { return new Rect(c.x - r, c.y - r, r * 2f, r * 2f); }
    Rect JumpR { get { return Circ(new Vector2(UIScale.W - 110f, UIScale.H - 245f), 45f); } }
    Rect BreakR { get { return Circ(new Vector2(UIScale.W - 100f, UIScale.H - 120f), 55f); } }
    Rect PlaceR { get { return Circ(new Vector2(UIScale.W - 230f, UIScale.H - 85f), 45f); } }
    Rect FpsR { get { return new Rect(UIScale.W - 92f, 8f, 84f, 34f); } }

    void Awake()
    {
        const int n = 64;
        circle = new Texture2D(n, n, TextureFormat.RGBA32, false);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(n / 2f - 0.5f, n / 2f - 0.5f));
                float a = Mathf.Clamp01((n / 2f - d)) ;
                circle.SetPixel(x, y, new Color(1, 1, 1, a));
            }
        circle.Apply();
    }

    void OnApplicationFocus(bool f) { if (!f) joyId = lookId = jumpId = breakId = -1; }

    void Update()
    {
        if (!Application.isMobilePlatform) return;
        InputState.BeginFrame();
        lookAcc = Vector2.zero;
        float s = UIScale.S, vw = UIScale.W;

        foreach (Touch t in Input.touches)
        {
            Vector2 p = new Vector2(t.position.x / s, (Screen.height - t.position.y) / s);
            int id = t.fingerId;
            switch (t.phase)
            {
                case TouchPhase.Began:
                    if (HitButtons(p, id)) break;
                    if (p.x < vw * 0.45f && joyId < 0) { joyId = id; joyOrigin = p; joyPos = p; }
                    else if (lookId < 0) lookId = id;
                    break;
                case TouchPhase.Moved:
                case TouchPhase.Stationary:
                    if (id == joyId) joyPos = p;
                    else if (id == lookId) lookAcc += t.deltaPosition;
                    break;
                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    if (id == joyId) joyId = -1;
                    if (id == lookId) lookId = -1;
                    if (id == jumpId) jumpId = -1;
                    if (id == breakId) breakId = -1;
                    break;
            }
        }

        if (joyId >= 0)
        {
            Vector2 v = (joyPos - joyOrigin) / JoyR;
            v.y = -v.y;
            if (v.magnitude > 1f) v.Normalize();
            if (v.magnitude < 0.12f) v = Vector2.zero;
            InputState.Move = v;
        }
        InputState.Look = lookAcc * 0.12f * InputState.LookSens;
        InputState.Jump = jumpId >= 0;
        InputState.BreakHeld = breakId >= 0;
    }

    bool HitButtons(Vector2 p, int id)
    {
        if (JumpR.Contains(p)) { jumpId = id; return true; }
        if (BreakR.Contains(p)) { breakId = id; return true; }
        if (PlaceR.Contains(p)) { InputState.PlacePressed = true; return true; }
        if (FpsR.Contains(p)) { if (PerformanceManager.I != null) PerformanceManager.I.CycleTarget(); return true; }
        for (int i = 0; i < 9; i++)
            if (Hud.Slot(i).Contains(p)) { InputState.Selected = i; return true; }
        return false;
    }

    void DrawButton(Rect r, string text, bool pressed)
    {
        GUI.color = new Color(1, 1, 1, pressed ? 0.8f : buttonAlpha);
        GUI.DrawTexture(r, circle);
        GUI.color = Color.white;
        GUI.Label(r, text, btn);
    }

    void OnGUI()
    {
        if (!Application.isMobilePlatform || Event.current.type != EventType.Repaint) return;
        var old = GUI.matrix;
        GUI.matrix = Matrix4x4.Scale(new Vector3(UIScale.S, UIScale.S, 1f));
        if (btn == null)
        {
            btn = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = 15, fontStyle = FontStyle.Bold };
            btn.normal.textColor = Color.white;
        }

        Vector2 baseP = joyId >= 0 ? joyOrigin : new Vector2(120f, UIScale.H - 120f);
        Vector2 knob = baseP;
        if (joyId >= 0) knob = baseP + Vector2.ClampMagnitude(joyPos - joyOrigin, JoyR);
        GUI.color = new Color(1, 1, 1, 0.25f);
        GUI.DrawTexture(Circ(baseP, JoyR), circle);
        GUI.color = new Color(1, 1, 1, 0.55f);
        GUI.DrawTexture(Circ(knob, 30f), circle);
        GUI.color = Color.white;

        DrawButton(JumpR, "JUMP", jumpId >= 0);
        DrawButton(BreakR, "BREAK", breakId >= 0);
        DrawButton(PlaceR, "PLACE", false);

        Hud.Box(FpsR, new Color(0, 0, 0, 0.45f));
        var pm = PerformanceManager.I;
        GUI.Label(FpsR, (pm != null ? pm.TargetFps : 60) + " FPS", btn);
        GUI.matrix = old;
    }
}
