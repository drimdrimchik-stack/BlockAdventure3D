using UnityEngine;

// Автозапуск: сцена может быть ПУСТОЙ — вся игра собирается из кода при старте
public static class GameBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Init()
    {
        if (Object.FindFirstObjectByType<ChunkManager>() != null) return;
        foreach (var c in Object.FindObjectsByType<Camera>(FindObjectsSortMode.None))
            Object.Destroy(c.gameObject);

        if (Application.isMobilePlatform)
        {
            Screen.orientation = ScreenOrientation.LandscapeLeft;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }

        int seed = PlayerPrefs.GetInt("ba_seed", 0);
        if (seed == 0) { seed = Random.Range(1, 99999); PlayerPrefs.SetInt("ba_seed", seed); }
        var gen = new WorldGenerator(seed);

        var root = new GameObject("BlockAdventure");
        root.AddComponent<PerformanceManager>();

        // Игрок
        var pgo = new GameObject("Player");
        var cc = pgo.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.9f, 0);
        cc.stepOffset = 0.55f; cc.skinWidth = 0.04f;
        var pc = pgo.AddComponent<PlayerController>();

        var camGo = new GameObject("PlayerCamera");
        camGo.tag = "MainCamera";
        camGo.transform.SetParent(pgo.transform, false);
        camGo.transform.localPosition = new Vector3(0, 1.62f, 0);
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 70f; cam.nearClipPlane = 0.05f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = ChunkManager.SkyColor;
        camGo.AddComponent<AudioListener>();
        var camCtl = camGo.AddComponent<CameraController>();

        // Точка появления: ближайшая суша
        int sx = 8, sz = 8;
        for (int i = 0; i < 3000 && gen.Height(sx, sz) <= WorldGenerator.Sea + 1; i++) { sx += 7; sz += 3; }
        pc.Init(camCtl, new Vector3(sx + 0.5f, gen.Height(sx, sz) + 2.5f, sz + 0.5f));

        // Материалы
        var shader = Resources.Load<Shader>("VoxelUnlit");
        if (shader == null) shader = Shader.Find("Sprites/Default");
        var solid = new Material(shader);
        var water = new Material(Shader.Find("Sprites/Default"));

        var cm = root.AddComponent<ChunkManager>();
        cm.Init(gen, pgo.transform, solid, water, cam);

        root.AddComponent<DesktopInput>();
        root.AddComponent<MobileUI>();
        var hud = root.AddComponent<Hud>();
        hud.player = pc;
        var bs = root.AddComponent<BlockSystem>();
        bs.Init(pc, cam, cc);
    }
}
