using UnityEngine;

// Ломание и установка блоков + подсветка целевого блока
public class BlockSystem : MonoBehaviour
{
    public static readonly byte[] Hotbar =
    {
        BlockId.Grass, BlockId.Dirt, BlockId.Stone, BlockId.Sand, BlockId.Wood,
        BlockId.Planks, BlockId.Cobble, BlockId.Leaves, BlockId.Snow
    };
    const float Reach = 5.5f;

    PlayerController player;
    Camera cam;
    CharacterController cc;
    GameObject highlight;
    Material hlMat;

    bool hasTarget;
    Vector3Int target, normal, breaking;
    float progress;

    public void Init(PlayerController p, Camera c, CharacterController controller)
    {
        player = p; cam = c; cc = controller;
        highlight = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Destroy(highlight.GetComponent<Collider>());
        highlight.transform.localScale = Vector3.one * 1.004f;
        hlMat = new Material(Shader.Find("Sprites/Default"));
        highlight.GetComponent<MeshRenderer>().sharedMaterial = hlMat;
        highlight.SetActive(false);
    }

    void Update()
    {
        if (player == null || !player.Ready) return;
        var cm = ChunkManager.I;
        Transform ct = cam.transform;
        hasTarget = Raycast(cm, ct.position, ct.forward, Reach, out target, out normal);

        if (!hasTarget)
        {
            highlight.SetActive(false);
            progress = 0f;
            return;
        }

        highlight.SetActive(true);
        highlight.transform.position = new Vector3(target.x + 0.5f, target.y + 0.5f, target.z + 0.5f);

        // Ломание (удержание)
        if (InputState.BreakHeld)
        {
            byte b = cm.GetBlock(target.x, target.y, target.z);
            float hard = Blocks.Hardness(b);
            if (hard >= 0f)
            {
                if (target != breaking) { breaking = target; progress = 0f; }
                progress += Time.deltaTime / Mathf.Max(0.05f, hard);
                if (progress >= 1f)
                {
                    cm.SetBlock(target.x, target.y, target.z, BlockId.Air);
                    progress = 0f;
                }
            }
        }
        else progress = 0f;

        hlMat.color = new Color(0f, 0f, 0f, 0.12f + 0.55f * Mathf.Clamp01(progress));

        // Установка
        if (InputState.PlacePressed)
        {
            var p = target + normal;
            byte cur = cm.GetBlock(p.x, p.y, p.z);
            if ((cur == BlockId.Air || cur == BlockId.Water) && p.y >= 0 && p.y < Chunk.H)
            {
                var bb = new Bounds(new Vector3(p.x + 0.5f, p.y + 0.5f, p.z + 0.5f), Vector3.one);
                if (!bb.Intersects(cc.bounds))
                    cm.SetBlock(p.x, p.y, p.z, Hotbar[InputState.Selected]);
            }
        }
    }

    // Воксельный луч (алгоритм DDA)
    static bool Raycast(ChunkManager cm, Vector3 o, Vector3 d, float max, out Vector3Int hit, out Vector3Int nrm)
    {
        hit = default; nrm = default;
        int x = Mathf.FloorToInt(o.x), y = Mathf.FloorToInt(o.y), z = Mathf.FloorToInt(o.z);
        int sx = d.x > 0 ? 1 : -1, sy = d.y > 0 ? 1 : -1, sz = d.z > 0 ? 1 : -1;
        float inf = float.PositiveInfinity;
        float tdx = d.x != 0 ? Mathf.Abs(1f / d.x) : inf;
        float tdy = d.y != 0 ? Mathf.Abs(1f / d.y) : inf;
        float tdz = d.z != 0 ? Mathf.Abs(1f / d.z) : inf;
        float tmx = d.x > 0 ? (x + 1 - o.x) * tdx : d.x < 0 ? (o.x - x) * tdx : inf;
        float tmy = d.y > 0 ? (y + 1 - o.y) * tdy : d.y < 0 ? (o.y - y) * tdy : inf;
        float tmz = d.z > 0 ? (z + 1 - o.z) * tdz : d.z < 0 ? (o.z - z) * tdz : inf;
        Vector3Int n = Vector3Int.zero;

        for (int i = 0; i < 64; i++)
        {
            if (Blocks.Targetable(cm.GetBlock(x, y, z)))
            {
                hit = new Vector3Int(x, y, z); nrm = n; return true;
            }
            if (tmx < tmy && tmx < tmz)
            {
                if (tmx > max) return false;
                x += sx; tmx += tdx; n = new Vector3Int(-sx, 0, 0);
            }
            else if (tmy < tmz)
            {
                if (tmy > max) return false;
                y += sy; tmy += tdy; n = new Vector3Int(0, -sy, 0);
            }
            else
            {
                if (tmz > max) return false;
                z += sz; tmz += tdz; n = new Vector3Int(0, 0, -sz);
            }
        }
        return false;
    }
}
