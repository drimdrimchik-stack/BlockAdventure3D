using System.Collections.Generic;
using UnityEngine;

public class Chunk
{
    public const int W = 16, H = 64;
    public static int Idx(int x, int y, int z) { return x | (z << 4) | (y << 8); }

    public Vector2Int pos;
    public byte[] data;
    public volatile bool hasData;
    public bool dirty = true;
    public bool modified;
    public ChunkView view;
}

public class ChunkView
{
    public GameObject go;
    public MeshCollider col;
    public Mesh solid, water;
    public bool colliderAssigned;
}

// Строит меши чанка: скрытые грани не создаются (face culling)
public static class Mesher
{
    static readonly List<Vector3> sv = new List<Vector3>(8192), wv = new List<Vector3>(1024);
    static readonly List<Color32> sc = new List<Color32>(8192), wc = new List<Color32>(1024);
    static readonly List<int> st = new List<int>(12288), wt = new List<int>(1536);

    static readonly int[] dx = { 1, -1, 0, 0, 0, 0 };
    static readonly int[] dy = { 0, 0, 1, -1, 0, 0 };
    static readonly int[] dz = { 0, 0, 0, 0, 1, -1 };
    static readonly float[] shade = { 0.8f, 0.8f, 1f, 0.5f, 0.7f, 0.7f };

    static readonly Vector3[][] corners =
    {
        new[] { new Vector3(1,0,0), new Vector3(1,1,0), new Vector3(1,1,1), new Vector3(1,0,1) }, // +X
        new[] { new Vector3(0,0,1), new Vector3(0,1,1), new Vector3(0,1,0), new Vector3(0,0,0) }, // -X
        new[] { new Vector3(0,1,0), new Vector3(0,1,1), new Vector3(1,1,1), new Vector3(1,1,0) }, // +Y
        new[] { new Vector3(1,0,0), new Vector3(1,0,1), new Vector3(0,0,1), new Vector3(0,0,0) }, // -Y
        new[] { new Vector3(1,0,1), new Vector3(1,1,1), new Vector3(0,1,1), new Vector3(0,0,1) }, // +Z
        new[] { new Vector3(0,0,0), new Vector3(0,1,0), new Vector3(1,1,0), new Vector3(1,0,0) }, // -Z
    };

    // nb: 0=+X 1=-X 2=+Z 3=-Z
    static byte Get(Chunk c, Chunk[] nb, int x, int y, int z)
    {
        if (y < 0) return BlockId.Stone;
        if (y >= Chunk.H) return BlockId.Air;
        if (x < 0) { var n = nb[1]; return n != null && n.hasData ? n.data[Chunk.Idx(15, y, z)] : BlockId.Air; }
        if (x >= Chunk.W) { var n = nb[0]; return n != null && n.hasData ? n.data[Chunk.Idx(0, y, z)] : BlockId.Air; }
        if (z < 0) { var n = nb[3]; return n != null && n.hasData ? n.data[Chunk.Idx(x, y, 15)] : BlockId.Air; }
        if (z >= Chunk.W) { var n = nb[2]; return n != null && n.hasData ? n.data[Chunk.Idx(x, y, 0)] : BlockId.Air; }
        return c.data[Chunk.Idx(x, y, z)];
    }

    static void AddFace(List<Vector3> v, List<Color32> col, List<int> t, int x, int y, int z, int face, byte b, int wx, int wz)
    {
        int start = v.Count;
        var cr = corners[face];
        for (int i = 0; i < 4; i++) v.Add(new Vector3(x + cr[i].x, y + cr[i].y, z + cr[i].z));
        Color32 bc = Blocks.FaceColor(b, face);
        float s = shade[face] * (0.9f + 0.1f * NoiseUtil.Hash(wx, y, wz, 1));
        Color32 r = new Color32((byte)(bc.r * s), (byte)(bc.g * s), (byte)(bc.b * s), bc.a);
        col.Add(r); col.Add(r); col.Add(r); col.Add(r);
        t.Add(start); t.Add(start + 1); t.Add(start + 2);
        t.Add(start); t.Add(start + 2); t.Add(start + 3);
    }

    static void Apply(Mesh m, List<Vector3> v, List<Color32> c, List<int> t)
    {
        m.Clear();
        if (v.Count == 0) return;
        m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        m.SetVertices(v);
        m.SetColors(c);
        m.SetTriangles(t, 0);
        m.RecalculateBounds();
    }

    public static void Build(Chunk c, Chunk[] nb, Mesh solid, Mesh water)
    {
        sv.Clear(); sc.Clear(); st.Clear(); wv.Clear(); wc.Clear(); wt.Clear();
        int baseX = c.pos.x * Chunk.W, baseZ = c.pos.y * Chunk.W;

        for (int y = 0; y < Chunk.H; y++)
        for (int z = 0; z < Chunk.W; z++)
        for (int x = 0; x < Chunk.W; x++)
        {
            byte b = c.data[Chunk.Idx(x, y, z)];
            if (b == BlockId.Air) continue;
            bool isWater = b == BlockId.Water;
            for (int f = 0; f < 6; f++)
            {
                byte n = Get(c, nb, x + dx[f], y + dy[f], z + dz[f]);
                if (isWater)
                {
                    if (n == BlockId.Air) AddFace(wv, wc, wt, x, y, z, f, b, baseX + x, baseZ + z);
                }
                else if (n == BlockId.Air || n == BlockId.Water)
                {
                    AddFace(sv, sc, st, x, y, z, f, b, baseX + x, baseZ + z);
                }
            }
        }
        Apply(solid, sv, sc, st);
        Apply(water, wv, wc, wt);
    }
}
