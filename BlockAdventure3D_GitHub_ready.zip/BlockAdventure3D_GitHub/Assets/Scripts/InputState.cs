using UnityEngine;

// Общее состояние ввода: его заполняют DesktopInput (ПК) или MobileUI (телефон)
public static class InputState
{
    public static Vector2 Move;      // x вправо, y вперёд
    public static Vector2 Look;      // градусы за кадр (x — поворот, y — вверх)
    public static bool Jump, Sprint, BreakHeld, PlacePressed;
    public static int Selected;      // выбранный слот хотбара 0..8
    public static float LookSens = 1f;

    public static void BeginFrame()
    {
        Move = Vector2.zero; Look = Vector2.zero;
        Jump = false; Sprint = false; BreakHeld = false; PlacePressed = false;
    }
    public static void SelectOffset(int d) { Selected = ((Selected + d) % 9 + 9) % 9; }
}
