using UnityEngine;

public class CameraController : MonoBehaviour
{
    float pitch;
    public void AddPitch(float d)
    {
        pitch = Mathf.Clamp(pitch + d, -89f, 89f);
        transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }
}
